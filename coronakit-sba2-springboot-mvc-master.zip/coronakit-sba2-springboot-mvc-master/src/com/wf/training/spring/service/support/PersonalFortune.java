package com.wf.training.spring.service.support;

public class PersonalFortune implements IFortuneService {

	@Override
	public String dailyFortune() {
		return "Today is your lucky day!";
	}

}
