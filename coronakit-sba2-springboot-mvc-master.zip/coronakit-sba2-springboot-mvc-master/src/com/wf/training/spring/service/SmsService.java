package com.wf.training.spring.service;

public class SmsService implements IMessageService {

	@Override
	public String sendMessage(String to, String message) {
		return "SMS send to : " + to + "[ " + message + " ]";
	}

}
