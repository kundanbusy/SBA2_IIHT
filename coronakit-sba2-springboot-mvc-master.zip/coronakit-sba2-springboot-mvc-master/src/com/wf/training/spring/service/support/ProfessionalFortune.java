package com.wf.training.spring.service.support;

public class ProfessionalFortune implements IFortuneService {

	@Override
	public String dailyFortune() {
		return "Boss is going to get impressed by your work!";
	}

}
